package Visitor;

public interface Elemento {
	
	public void afectar(Visitante v);
	
	}
