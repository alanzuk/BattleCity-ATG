package Poderes;
import General.GameObject;

public abstract class Powerup {
	private GameObject ubicacion;
	
	public abstract void efecto();
	public GameObject getUbicacion(){
		return ubicacion;
	}
}
