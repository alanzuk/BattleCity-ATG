package Poderes;

import Visitor.Visitante;

public class Reloj {

	
	public void afectar(Visitante v){
		v.visit(this);
		
	}
}
