package Poderes;

import Visitor.Visitante;

public class Vida {

	
	public void afectar(Visitante v){
		v.visit(this);
		
	}
}


