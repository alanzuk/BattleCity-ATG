package Poderes;

import Visitor.Visitante;

public class Estrella {

	
	public void afectar(Visitante v){
		v.visit(this);
		
	}
}
